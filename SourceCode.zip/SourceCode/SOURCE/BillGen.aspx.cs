﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["apptregstr"].ConnectionString);
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        con1.Open();
        cmd = new SqlCommand("insert into Bill values('" + DropDownList5.SelectedItem + "','" + TextBox1.Text + "','" + TextBox5.Text + "','" + DropDownList4.SelectedItem + "','" + DropDownList2.SelectedItem + "','" + DropDownList3.SelectedItem + "','" + TextBox6.Text + "')", con1);
        cmd.ExecuteNonQuery();

        Response.Write("<script>alert('Bill Generated Successfully...');</script>");
        con1.Close();
    }
    
}