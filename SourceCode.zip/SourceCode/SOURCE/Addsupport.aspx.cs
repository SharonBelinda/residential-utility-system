﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["apptregstr"].ConnectionString);
    SqlCommand cm = new SqlCommand();
    string gender = "not selected";
    

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
if(RadioButton1.Checked)
{
    gender = "Male";
}
else if(RadioButton2.Checked)
{
    gender = "Female";
}

        con.Open();
        cm = new SqlCommand("insert into SupReg values('" + TextBox1.Text + "','" + TextBox5.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','"+DropDownList1.SelectedItem.Text+"','"+gender+"')", con);
        cm.ExecuteNonQuery();
        Response.Write("<script>alert('Support Team details Registered Successfully...');</script>");
        con.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}